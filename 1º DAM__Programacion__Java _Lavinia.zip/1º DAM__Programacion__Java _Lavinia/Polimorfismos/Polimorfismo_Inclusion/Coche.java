package Polimorfismos.Polimorfismo_Inclusion;
public class Coche extends Vehiculo {

    // Definiendo el mismo método que en la clase padre
    public void Setcorrer() {
        System.out.println("El vehículo está corriendo de forma segura");
    }

}
