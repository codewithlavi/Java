package Polimorfismos.Polimorfismo_Inclusion;
public class MainVehiculo {
    public static void main(String args[]) {
        Coche coche = new Coche();// Creando cocheeto
        coche.Setcorrer();// Llamando al método
    }
}
