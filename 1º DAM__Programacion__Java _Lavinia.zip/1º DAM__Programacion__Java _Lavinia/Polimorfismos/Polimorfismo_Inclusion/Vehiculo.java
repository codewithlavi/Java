package Polimorfismos.Polimorfismo_Inclusion;

public class Vehiculo {
    public void Setcorrer() {
        System.out.println("El vehículo se está moviendo");
    }
}
