package Polimorfismos.Polimorfismo_Asignación;

class Perro extends Animal {
    public void setSonido() {
        System.out.println("Guauu");
    }

}