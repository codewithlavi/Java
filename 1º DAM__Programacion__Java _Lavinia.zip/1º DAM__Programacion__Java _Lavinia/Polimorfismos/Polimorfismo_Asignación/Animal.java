package Polimorfismos.Polimorfismo_Asignación;

class Animal {
    public void setSonido() {
        System.out.println("Sonido de animal");
    }

}