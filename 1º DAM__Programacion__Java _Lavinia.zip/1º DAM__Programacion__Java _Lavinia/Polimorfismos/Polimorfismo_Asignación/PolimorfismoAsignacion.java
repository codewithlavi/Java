package Polimorfismos.Polimorfismo_Asignación;

public class PolimorfismoAsignacion {
    public static void main(String[] args) {
        Animal miAnimal = new Perro(); // Asignación de un objeto de tipo Perro a una referencia de tipo Animal
        miAnimal.setSonido();
    }
}
