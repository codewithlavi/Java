package POO.Cine;
class Espectador {
    String nombre;
    int edad;
    double dinero;

    // Constructor de la clase Espectador
    public Espectador(String nombre, int edad, double dinero) {
        this.nombre = nombre;
        this.edad = edad;
        this.dinero = dinero;
    }
}
