package POO.Vectores;
public class VectorMain2 {
    
    public static void main(String[] args) {
        
        VectorABC vectores= new VectorABC();
        System.out.print("Este es el vector A: " );
        vectores.getVectorA();
        System.out.print("Este es el vector B: " );
        vectores.getVectorB();
        System.out.println("La suma del vector A y del vector B es..");
        System.out.print("El vector C: " );
        vectores.GetVectorC();

    }
}
