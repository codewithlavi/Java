package POO.Vector;
public class VectorMain {

    public static void main(String[] args) {

        Vector vector = new Vector();

        System.out.println("Te muestro el vector al derecho:");
        vector.getVectorDerecho();
        System.out.println("Te muestro el vector del reves:");
        vector.getVectorDelreves();
    }
}
